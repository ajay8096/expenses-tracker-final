import NavBarApp from "./Components/NavBarApp";


function App() {
  return (
   <div>

    
    <NavBarApp/>
   
    
   
    
   </div>
  );
}

export default App;
